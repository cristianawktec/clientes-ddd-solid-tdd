# 🚀 Instruções de Deploy para Hostgator

## 📋 Checklist de Deploy

### ✅ Pré-requisitos
- [ ] Arquivo `clientes-hostgator-deploy.zip` criado
- [ ] Acesso ao cPanel da Hostgator
- [ ] Credenciais do banco MySQL da Hostgator

### 📤 1. Upload dos Arquivos

1. **Acesse o cPanel** da sua conta Hostgator
2. **Abra o File Manager**
3. **Navegue para** `public_html/`
4. **Crie uma pasta** (ex: `clientes`) ou use a raiz
5. **Upload** do arquivo `clientes-hostgator-deploy.zip`
6. **Clique com botão direito** no arquivo ZIP → **Extract**
7. **Delete** o arquivo ZIP após extrair

### 🗄️ 2. Configuração do Banco de Dados

#### No cPanel:
1. **MySQL Databases** → Criar banco de dados
2. **Criar usuário** MySQL
3. **Associar usuário** ao banco
4. **Anotar as credenciais:**
   - Host: `localhost`
   - Database: `cpanel_usuario_nomedobanco`
   - Username: `cpanel_usuario_nomeuser`
   - Password: `sua_senha`

#### No servidor:
1. **Editar** o arquivo `application/config/database.php`
2. **Alterar as configurações:**

```php
$db['default']['hostname'] = 'localhost';
$db['default']['username'] = 'cpanel_usuario_nomeuser';  // ALTERAR
$db['default']['password'] = 'sua_senha_mysql';          // ALTERAR  
$db['default']['database'] = 'cpanel_usuario_nomedobanco'; // ALTERAR
$db['default']['dbdriver'] = 'mysqli';
$db['default']['dbprefix'] = '';
$db['default']['pconnect'] = FALSE;
$db['default']['db_debug'] = FALSE; // IMPORTANTE: FALSE em produção
$db['default']['cache_on'] = FALSE;
$db['default']['cachedir'] = '';
$db['default']['char_set'] = 'utf8';
$db['default']['dbcollat'] = 'utf8_general_ci';
$db['default']['swap_pre'] = '';
$db['default']['encrypt'] = FALSE;
$db['default']['compress'] = FALSE;
$db['default']['stricton'] = FALSE;
$db['default']['failover'] = array();
$db['default']['save_queries'] = TRUE;
```

### 📊 3. Importar Banco de Dados

1. **phpMyAdmin** no cPanel
2. **Selecionar** o banco criado
3. **Import** → Escolher arquivo `modelo_relacional_clientes.sql`
4. **Executar** a importação

### 🔧 4. Configurações Finais

#### Permissões:
- **Pasta `uploads/`**: 755 ou 777
- **Pasta `application/cache/`**: 755
- **Pasta `application/logs/`**: 755

#### Teste:
1. **Acessar** `seudominio.com/clientes` (ou onde instalou)
2. **Verificar** se carrega a página inicial
3. **Testar** cadastro de cliente

### 🐛 Troubleshooting

#### Se der erro 500:
1. **Verificar** o arquivo `.htaccess`
2. **Verificar** permissões das pastas
3. **Verificar** configuração do banco

#### Se não conectar ao banco:
1. **Verificar** credenciais no `database.php`
2. **Verificar** se o usuário tem permissão no banco
3. **Verificar** se o banco foi criado corretamente

### 📝 URLs importantes:

- **Site principal**: `seudominio.com/clientes`
- **API**: `seudominio.com/clientes/cliente`
- **cPanel**: `cpanel.seudominio.com`
- **phpMyAdmin**: `seudominio.com/phpmyadmin`

### 🔄 Para futuras atualizações:

1. **Fazer mudanças** em `c:\xampp\htdocs\clientes-production\`
2. **Testar** em `localhost/clientes-production`
3. **Commit** no git
4. **Gerar novo ZIP**
5. **Upload e substituir** no servidor

---

## ✅ Após completar todos os passos, o sistema estará rodando na Hostgator!